import os
import tempfile
from pathlib import Path
import pytest

@pytest.fixture
def isolated_log_path(tmp_path, monkeypatch):
    path = tmp_path / "test.log"
    monkeypatch.setenv("APP_LOG_FILE", str(path))
    return path
