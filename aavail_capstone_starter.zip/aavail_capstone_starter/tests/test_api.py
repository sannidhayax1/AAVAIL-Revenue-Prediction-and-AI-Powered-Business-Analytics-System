import json
from fastapi.testclient import TestClient
import pandas as pd
import app.main as main

def test_health():
    client = TestClient(main.app)
    assert client.get("/health").json() == {"status": "ok"}

def test_predict_country_and_all(tmp_path, monkeypatch):
    csv = tmp_path / "transactions.csv"
    pd.DataFrame([
        {"Country": "UK", "Quantity": 2, "UnitPrice": 5, "Revenue": 10},
        {"Country": "USA", "Quantity": 3, "UnitPrice": 4, "Revenue": 12}
    ]).to_csv(csv, index=False)
    model_file = tmp_path / "model.joblib"
    from app.model import train_and_save
    train_and_save(csv, model_file)
    monkeypatch.setattr(main, "DATA_PROCESSED", csv)
    monkeypatch.setattr(main, "MODEL_FILE", model_file)
    client = TestClient(main.app)
    assert client.get("/predict?country=UK").status_code == 200
    assert client.get("/predict").status_code == 200
    assert client.get("/predict?country=NotARealCountry").status_code == 404
