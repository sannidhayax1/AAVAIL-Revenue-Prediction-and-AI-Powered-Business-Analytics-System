import json
from pathlib import Path
import pandas as pd
import pytest
from scripts.ingest_data import ingest

def test_ingest_valid_json(tmp_path):
    raw = tmp_path / "raw"
    raw.mkdir()
    (raw / "sample.json").write_text(json.dumps([{
        "Country": "UK", "Quantity": 2, "UnitPrice": 5, "Revenue": 10
    }]), encoding="utf-8")
    output = tmp_path / "processed" / "data.csv"
    df = ingest(raw, output)
    assert len(df) == 1
    assert output.exists()
    assert df.iloc[0]["Revenue"] == 10

def test_ingest_missing_columns_fails(tmp_path):
    raw = tmp_path / "raw"
    raw.mkdir()
    (raw / "sample.json").write_text(json.dumps([{"Country": "UK"}]), encoding="utf-8")
    with pytest.raises(ValueError):
        ingest(raw, tmp_path / "out.csv")
