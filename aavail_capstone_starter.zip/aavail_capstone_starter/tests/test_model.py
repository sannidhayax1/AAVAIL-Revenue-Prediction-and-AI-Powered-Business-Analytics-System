import pandas as pd
from app.model import train_and_save, load_model

def test_model_trains_and_predicts(tmp_path):
    df = pd.DataFrame([
        {"Country": "UK" if i % 2 else "USA", "Quantity": i % 5 + 1,
         "UnitPrice": float(i % 10 + 1), "Revenue": float((i % 5 + 1) * (i % 10 + 1))}
        for i in range(80)
    ])
    csv = tmp_path / "data.csv"
    model_file = tmp_path / "model.joblib"
    df.to_csv(csv, index=False)
    result = train_and_save(csv, model_file)
    bundle = load_model(model_file)
    pred = bundle["model"].predict(pd.DataFrame([{
        "Country": "UK", "Quantity": 2, "UnitPrice": 5.0
    }]))
    assert model_file.exists()
    assert len(pred) == 1
    assert result["mae_by_model"]
