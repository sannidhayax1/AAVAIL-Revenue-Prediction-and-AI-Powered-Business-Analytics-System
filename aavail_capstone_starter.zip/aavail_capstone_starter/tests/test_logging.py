import logging
from app.logging_config import get_logger

def test_logger_writes_to_isolated_test_file(tmp_path):
    path = tmp_path / "isolated-test.log"
    logger = get_logger("test_logger_isolated_unique", path)
    logger.info("test-event")
    for handler in logger.handlers:
        handler.flush()
    assert path.exists()
    assert "test-event" in path.read_text(encoding="utf-8")
