# AAVAIL Business Revenue Prediction — Capstone Starter

This is a **starter scaffold**, not a verified final submission. Replace the clearly marked demo data with the course's actual AAVAIL JSON files, run every command, inspect the outputs, and adapt the analysis in your own words before submitting.

## Project goals
- Ingest transaction JSON/CSV data
- Explore revenue patterns with visualizations
- Compare a simple baseline with multiple ML models
- Expose predictions through a FastAPI API
- Test API, model, and logging
- Keep tests isolated from production logs/data
- Run in Docker

## Quick start (Python 3.11+)
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python scripts/generate_demo_data.py
python scripts/ingest_data.py
python scripts/eda.py
python scripts/train_model.py
pytest
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs` to try the API.

## API examples
- `GET /health`
- `GET /predict?country=United%20Kingdom`
- `GET /predict` (all countries combined)

The current model is a demonstration that estimates revenue from a country-level aggregate. It is **not a production-grade forecasting system**. Review and improve the target definition and features using the actual course data.

## Replace demo data with course data
Put the course JSON files under `data/raw/`. Update `scripts/ingest_data.py` to match the actual JSON schema. The demo generator creates synthetic records solely to make the scaffold runnable; its results are not answers to course quiz questions.

## What to review before submission
- [ ] Use the real course data and document its schema
- [ ] Confirm data leakage is avoided and choose a meaningful prediction target
- [ ] Explain model selection and metrics in your own words
- [ ] Run `pytest` and fix any failures
- [ ] Build and run Docker locally
- [ ] Add screenshots/outputs from your own run
- [ ] Push to your own public GitHub repository and test the URL
