import json
from pathlib import Path
from app.config import DATA_PROCESSED, MODEL_FILE
from app.model import train_and_save

if __name__ == "__main__":
    result = train_and_save(DATA_PROCESSED, MODEL_FILE)
    Path("artifacts").mkdir(exist_ok=True)
    Path("artifacts/model_metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
