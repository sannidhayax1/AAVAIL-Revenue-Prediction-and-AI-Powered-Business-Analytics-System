from pathlib import Path
import json
import pandas as pd

RAW = Path("data/raw")
OUT = Path("data/processed/transactions.csv")
REQUIRED = {"Country", "Quantity", "UnitPrice", "Revenue"}

def ingest(raw_dir: Path = RAW, output_path: Path = OUT) -> pd.DataFrame:
    frames = []
    for path in raw_dir.glob("*.json"):
        with path.open(encoding="utf-8") as f:
            obj = json.load(f)
        if isinstance(obj, dict):
            obj = obj.get("data", obj.get("transactions", [obj]))
        frames.append(pd.DataFrame(obj))
    if not frames:
        raise FileNotFoundError(f"No JSON files found in {raw_dir}")
    df = pd.concat(frames, ignore_index=True)
    missing = REQUIRED - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    for col in ["Quantity", "UnitPrice", "Revenue"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.replace([float("inf"), float("-inf")], pd.NA).dropna(subset=list(REQUIRED))
    df = df[(df["Quantity"] > 0) & (df["UnitPrice"] >= 0) & (df["Revenue"] >= 0)]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    return df

if __name__ == "__main__":
    data = ingest()
    print(f"Ingested {len(data)} rows -> {OUT}")
