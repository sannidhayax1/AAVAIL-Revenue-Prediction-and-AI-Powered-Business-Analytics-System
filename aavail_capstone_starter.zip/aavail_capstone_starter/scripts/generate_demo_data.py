# Synthetic demo data only. Replace with actual course data before submission.
from pathlib import Path
import json, random
random.seed(42)
out = Path("data/raw")
out.mkdir(parents=True, exist_ok=True)
countries = ["United Kingdom", "USA", "Germany", "EIRE", "Singapore"]
records = []
for i in range(1200):
    country = random.choice(countries)
    quantity = random.randint(1, 12)
    unit_price = round(random.uniform(2, 80), 2)
    records.append({
        "InvoiceDate": f"2025-{(i % 12)+1:02d}-{(i % 27)+1:02d}",
        "Country": country,
        "Quantity": quantity,
        "UnitPrice": unit_price,
        "Revenue": round(quantity * unit_price, 2)
    })
with (out / "demo_transactions.json").open("w", encoding="utf-8") as f:
    json.dump(records, f, indent=2)
print(f"Wrote {len(records)} synthetic demo rows to {out / 'demo_transactions.json'}")
