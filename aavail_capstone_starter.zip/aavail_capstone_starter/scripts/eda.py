from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/processed/transactions.csv")
out = Path("artifacts/eda")
out.mkdir(parents=True, exist_ok=True)
df.groupby("Country")["Revenue"].sum().sort_values(ascending=False).plot(kind="bar")
plt.title("Total Revenue by Country")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig(out / "revenue_by_country.png")
plt.close()
df["Revenue"].plot(kind="hist", bins=30)
plt.title("Transaction Revenue Distribution")
plt.xlabel("Revenue")
plt.tight_layout()
plt.savefig(out / "revenue_distribution.png")
plt.close()
print(f"EDA charts saved to {out}")
