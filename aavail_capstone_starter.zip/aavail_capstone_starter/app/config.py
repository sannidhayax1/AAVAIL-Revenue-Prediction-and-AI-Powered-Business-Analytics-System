import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
DATA_PROCESSED = ROOT / "data" / "processed" / "transactions.csv"
LOG_FILE = Path(os.getenv("APP_LOG_FILE", str(ROOT / "logs" / "app.log")))
MODEL_FILE = ARTIFACTS / "revenue_model.joblib"
