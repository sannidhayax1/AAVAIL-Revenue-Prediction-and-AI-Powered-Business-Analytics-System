from fastapi import FastAPI, HTTPException, Query
import pandas as pd
from app.config import DATA_PROCESSED, MODEL_FILE, LOG_FILE
from app.logging_config import get_logger
from app.model import load_model

app = FastAPI(title="AAVAIL Revenue Prediction API", version="0.1.0")
logger = get_logger("aavail_api", LOG_FILE)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/predict")
def predict(country: str | None = Query(default=None, description="Country; omit for all-country aggregate")):
    if not DATA_PROCESSED.exists():
        raise HTTPException(status_code=503, detail="Processed data missing; run scripts/ingest_data.py")
    if not MODEL_FILE.exists():
        raise HTTPException(status_code=503, detail="Model missing; run scripts/train_model.py")
    df = pd.read_csv(DATA_PROCESSED)
    if country:
        subset = df[df["Country"].str.casefold() == country.casefold()]
        if subset.empty:
            raise HTTPException(status_code=404, detail=f"Country not found: {country}")
    else:
        subset = df
        country = "ALL_COUNTRIES"
    # Aggregate the available feature values and estimate a representative transaction revenue.
    row = pd.DataFrame([{
        "Country": country if country != "ALL_COUNTRIES" else str(subset["Country"].mode().iloc[0]),
        "Quantity": float(subset["Quantity"].mean()),
        "UnitPrice": float(subset["UnitPrice"].mean())
    }])
    bundle = load_model(MODEL_FILE)
    prediction = float(bundle["model"].predict(row)[0])
    logger.info("prediction country=%s rows=%s model=%s", country, len(subset), bundle["name"])
    return {
        "country": country,
        "predicted_revenue_per_transaction": round(prediction, 2),
        "rows_considered": int(len(subset)),
        "model": bundle["name"]
    }
