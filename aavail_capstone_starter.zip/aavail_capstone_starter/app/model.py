from pathlib import Path
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split

FEATURES = ["Country", "Quantity", "UnitPrice"]
TARGET = "Revenue"

def build_pipeline(estimator):
    prep = ColumnTransformer([
        ("numeric", SimpleImputer(strategy="median"), ["Quantity", "UnitPrice"]),
        ("country", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))
        ]), ["Country"])
    ])
    return Pipeline([("prep", prep), ("model", estimator)])

def train_and_save(csv_path: str | Path, model_path: str | Path):
    df = pd.read_csv(csv_path)
    df = df.dropna(subset=[TARGET])
    X, y = df[FEATURES], df[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )
    candidates = {
        "baseline_mean": build_pipeline(DummyRegressor(strategy="mean")),
        "linear_regression": build_pipeline(LinearRegression()),
        "random_forest": build_pipeline(RandomForestRegressor(n_estimators=80, random_state=42)),
        "extra_trees": build_pipeline(ExtraTreesRegressor(n_estimators=80, random_state=42)),
    }
    results = {}
    fitted = {}
    for name, model in candidates.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        results[name] = float(mean_absolute_error(y_test, pred))
        fitted[name] = model
    best_name = min(results, key=results.get)
    model_path = Path(model_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": fitted[best_name], "name": best_name, "metrics": results}, model_path)
    return {"best_model": best_name, "mae_by_model": results, "test_rows": len(X_test)}

def load_model(model_path: str | Path):
    return joblib.load(model_path)
